-- postgre pass: postgre1

\c lab10 -- connet to database
select * form entries ;
